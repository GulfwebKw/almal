-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2022 at 09:14 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `almal`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `image`, `slug`, `parent_id`, `display_order`, `link`, `is_active`, `created_at`, `updated_at`) VALUES
(79, NULL, 'Board-Committees', 40, 46, NULL, 1, '2022-09-15 07:12:39', '2022-09-15 07:13:02'),
(80, NULL, 'Management-committees', 40, 47, NULL, 1, '2022-09-15 07:12:43', '2022-09-15 07:13:08'),
(81, NULL, 'Anti-Money-Laundering', 40, 48, NULL, 1, '2022-09-15 07:12:46', '2022-09-15 07:13:11'),
(82, NULL, 'Group-Risk-ManagementComplaince', 40, 49, NULL, 1, '2022-09-15 07:12:48', '2022-09-15 07:13:14'),
(83, NULL, 'Group-Internal-Audit', 40, 50, NULL, 1, '2022-09-15 07:12:51', '2022-09-15 07:13:16'),
(84, NULL, 'Financuial-Reporting', 40, 51, NULL, 1, '2022-09-15 07:12:53', '2022-09-15 07:13:19'),
(85, NULL, 'External-Audit', 40, 52, NULL, 1, '2022-09-15 07:12:55', '2022-09-15 07:13:21'),
(86, NULL, 'Code-of-Ethics--Conduct', 40, 53, NULL, 1, '2022-09-15 07:12:57', '2022-09-15 07:13:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
