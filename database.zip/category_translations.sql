-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2022 at 09:26 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `almal`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_translations`
--

INSERT INTO `category_translations` (`id`, `category_id`, `locale`, `title`, `meta_desc`) VALUES
(151, 79, 'en', 'Board Committees', 'Board Committees'),
(152, 79, 'ar', 'لجان مجلس الإدارة', 'لجان مجلس الإدارة'),
(153, 80, 'en', 'Management Committees', NULL),
(154, 80, 'ar', 'لجان الإدارة التنفيذية', NULL),
(155, 81, 'en', 'Anti  Money Laundering', NULL),
(156, 81, 'ar', 'مكافحة غسل الأموال وتمويل الارهاب', NULL),
(157, 82, 'en', 'Group Risk Management & Compliance', NULL),
(158, 82, 'ar', 'إدارة المخاطر والإلتزام الرقابي', NULL),
(159, 83, 'en', 'Group Internal Audit', NULL),
(160, 83, 'ar', 'إدارة التدقيق الداخلي', NULL),
(161, 84, 'en', 'Corporate governance', NULL),
(162, 84, 'ar', 'حوكمة الشركات', NULL),
(163, 85, 'en', 'External Audit', NULL),
(164, 85, 'ar', 'مدققي حسابات الشركة', NULL),
(165, 86, 'en', 'Code of Ethics / Conduct', NULL),
(166, 86, 'ar', 'قواعد السلوك المهني', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD KEY `category_translations_locale_index` (`locale`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
